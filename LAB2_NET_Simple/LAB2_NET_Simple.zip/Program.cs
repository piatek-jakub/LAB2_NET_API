﻿namespace LAB2_NET_Simple
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.UI();
        }
    }
}
