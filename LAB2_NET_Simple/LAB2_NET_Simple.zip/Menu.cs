﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace LAB2_NET_Simple
{
    internal class Menu
    {
        public Client client;
        public ExercisesDB exercisesDB;
        public Menu()
        {
            client = new Client();
            exercisesDB = new ExercisesDB();
        }
        public void UI()
        {
            int i = 2;
            while (i > 0)
            {
                string sampleString = "http://www.boredapi.com/api/activity/";
                client.GetData(sampleString).Wait();
                Exercise exercise = new Exercise {key = "abc" };
                var found = exercisesDB.exercises.FirstOrDefault(e => e.key == "abc");
                if (found == null)
                {
                    Console.WriteLine("Has to add this one!");
                    exercisesDB.exercises.Add(exercise);
                }
                else
                {
                    Console.WriteLine("watafak");
                }

                exercisesDB.SaveChanges();
                i--;
            }
            
        }
    }
}
